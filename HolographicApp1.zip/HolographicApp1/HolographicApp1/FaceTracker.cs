﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Windows.Graphics.Imaging;
using Windows.Media;
using Windows.Media.Capture;
using Windows.Media.FaceAnalysis;
using Windows.Media.MediaProperties;
using Windows.System.Threading;

namespace HolographicApp1
{
    public class FaceTrackerMine
    {

        private MediaCapture mediaCapture;
        private VideoEncodingProperties videoProperties;
        private ThreadPoolTimer frameProcessingTimer;
        private FaceTracker faceTracker;
        private SemaphoreSlim frameProcessingSemaphore = new SemaphoreSlim(1);
        //private CaptureElement videoFrames;
        uint frameOfDetectedFaceX = 640, frameOfDetectedFaceY = 480;


        public FaceTrackerMine()
        {
            this.ChangeScenarioState();
        }

        ~FaceTrackerMine()
        {
            ShutdownWebCam();
        }

        private async void ChangeScenarioState()
        {
            // Disable UI while state change is in progress

            if (this.faceTracker == null)
                this.faceTracker = await FaceTracker.CreateAsync();


            if (!await this.StartWebcamStreaming())
            {
                var t = Task.Run(() => this.ChangeScenarioState());
                return;
            }
        }

        private async void ShutdownWebCam()
        {
            if (this.frameProcessingTimer != null)
            {
                this.frameProcessingTimer.Cancel();
            }

            if (this.mediaCapture != null)
            {
                if (this.mediaCapture.CameraStreamState == Windows.Media.Devices.CameraStreamState.Streaming)
                {
                    try
                    {
                        await this.mediaCapture.StopPreviewAsync();
                    }
                    catch (Exception)
                    {
                        ;   // Since we're going to destroy the MediaCapture object there's nothing to do here
                    }
                }
                this.mediaCapture.Dispose();
            }

            this.frameProcessingTimer = null;
           // this.videoFrames.Source = null;
            this.mediaCapture = null;

        }

        private async Task<bool> StartWebcamStreaming()
        {

            bool successful = true;
            try
            {
                this.mediaCapture = new MediaCapture();
                // For this scenario, we only need Video (not microphone) so specify this in the initializer.
                // NOTE: the appxmanifest only declares "webcam" under capabilities and if this is changed to include
                // microphone (default constructor) you must add "microphone" to the manifest or initialization will fail.
                MediaCaptureInitializationSettings settings = new MediaCaptureInitializationSettings();
                settings.StreamingCaptureMode = StreamingCaptureMode.Video;
                await this.mediaCapture.InitializeAsync(settings);


                // Cache the media properties as we'll need them later.
                // Get information about the preview
                videoProperties = mediaCapture.VideoDeviceController.GetMediaStreamProperties(MediaStreamType.VideoPreview) as VideoEncodingProperties;

                //var deviceController = this.mediaCapture.VideoDeviceController;
                // Create a video frame in the desired format for the preview frame

                //this.videoProperties = deviceController.GetMediaStreamProperties(MediaStreamType.VideoPreview) as VideoEncodingProperties;

                // Immediately start streaming to our CaptureElement UI.
                // NOTE: CaptureElement's Source must be set before streaming is started.
                //this.videoFrames.Source = this.mediaCapture;
                //await this.mediaCapture.StartPreviewAsync();

                // Use a 66 millisecond interval for our timer, i.e. 15 frames per second
                TimeSpan timerInterval = TimeSpan.FromMilliseconds(66);
                this.frameProcessingTimer = ThreadPoolTimer.CreatePeriodicTimer(new Windows.System.Threading.TimerElapsedHandler(ProcessCurrentVideoFrame), timerInterval);
            }
            catch (System.UnauthorizedAccessException)
            {
                successful = false;
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        private async void ProcessCurrentVideoFrame(ThreadPoolTimer timer)
        {

            // If a lock is being held it means we're still waiting for processing work on the previous frame to complete.
            // In this situation, don't wait on the semaphore but exit immediately.
            if (!frameProcessingSemaphore.Wait(0))
            {
                return;
            }

            try
            {
                IList<DetectedFace> faces = null;

                // Create a VideoFrame object specifying the pixel format we want our capture image to be (NV12 bitmap in this case).
                // GetPreviewFrame will convert the native webcam frame into this format.
                const BitmapPixelFormat InputPixelFormat = BitmapPixelFormat.Nv12;
                // Create a video frame in the desired format for the preview frame
                using (VideoFrame previewFrame = new VideoFrame(InputPixelFormat, (int)this.videoProperties.Width, (int)this.videoProperties.Height))
                {
                    await this.mediaCapture.GetPreviewFrameAsync(previewFrame);

                    // The returned VideoFrame should be in the supported NV12 format but we need to verify this.
                    if (FaceDetector.IsBitmapPixelFormatSupported(previewFrame.SoftwareBitmap.BitmapPixelFormat))
                        faces = await this.faceTracker.ProcessNextFrameAsync(previewFrame);
                    else
                        throw new System.NotSupportedException("PixelFormat '" + InputPixelFormat.ToString() + "' is not supported by FaceDetector");

                    // Create our visualization using the frame dimensions and face results but run it on the UI thread.
                    var previewFrameSize = new Windows.Foundation.Size(previewFrame.SoftwareBitmap.PixelWidth, previewFrame.SoftwareBitmap.PixelHeight);
                    this.SetupVisualization(previewFrameSize, faces);

                    //var ignored = ThreadPool.RunAsync(delegate
                    //{
                    //    this.SetupVisualization(previewFrameSize, faces);
                    //});
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                frameProcessingSemaphore.Release();
            }

        }

        private void SetupVisualization(Windows.Foundation.Size framePizelSize, IList<DetectedFace> foundFaces)
        {
            //this.frameOfDetectedFace.Children.Clear();

            double actualWidth = 640;
            double actualHeight = 480;

            uint boxWidth, boxHeight, boxX, boxY;

            if (foundFaces != null && actualWidth != 0 && actualHeight != 0)
            {
                double widthScale = framePizelSize.Width / actualWidth;
                double heightScale = framePizelSize.Height / actualHeight;

                foreach (DetectedFace face in foundFaces)
                {

                    boxWidth = (uint)(face.FaceBox.Width / widthScale);
                    boxHeight = (uint)(face.FaceBox.Height / heightScale);
                    boxX = (uint)(face.FaceBox.X / widthScale);
                    boxY = (uint)(face.FaceBox.Y / heightScale);

                    uint windX = (uint)(face.FaceBox.X / widthScale);
                    uint windY = (uint)(face.FaceBox.Y / heightScale);
                    uint windWidth = (uint)(face.FaceBox.Width / widthScale);
                    uint windHeight = (uint)(face.FaceBox.Height / heightScale);

                    Debug.Write("Znaleziono kogos!\n Moje | Windowsa\n" + boxX + " | " + windX + ", " + boxY + " | " + windY + ", " + boxWidth + " | " + windWidth + ", " + boxHeight + " | " + windHeight + "\n");
                }
            }
        }
    }
}
